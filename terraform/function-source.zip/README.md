## Alert handler

Service responsible for processing alerts, validating and storing them in a KV store.
...
